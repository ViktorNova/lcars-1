jZend.Module = Base.extend({
	constructor: function () {
		this.init();
	},
	init: function () {
		
	}
});