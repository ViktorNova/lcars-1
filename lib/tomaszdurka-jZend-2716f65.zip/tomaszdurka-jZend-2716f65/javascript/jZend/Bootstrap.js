jZend.Bootstrap = Base.extend({
	
});