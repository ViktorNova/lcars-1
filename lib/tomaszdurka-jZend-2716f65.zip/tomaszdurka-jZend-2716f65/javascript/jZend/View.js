jZend.View = Base.extend({
	initialize: function () {
		this._layout = $('#layout');
		this._container = $('#view');
	}
	
});