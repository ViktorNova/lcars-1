$(document).ready(function () {
	var request = params;
	var app = new jZend.Application();
	app.bootstrap().run(request);
});