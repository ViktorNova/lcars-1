<?php


class jZend_Bootstrap {
	
	public function __construct($application) {
		
	}
	
}